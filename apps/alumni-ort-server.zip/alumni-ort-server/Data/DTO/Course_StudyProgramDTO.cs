using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OrtAlumniWeb.AlumniOrtServer.Data.DTO
{
  public class Course_StudyProgramDTO
  {
    public int Id { get; set; }
    public int StudyProgramId { get; set; }
    public string Name { get; set; }
  }
}